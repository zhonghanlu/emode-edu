import setupExtend from 'unplugin-vue-setup-extend-plus/vite'

export default function createSetupExtend() {
    return setupExtend({})
}
